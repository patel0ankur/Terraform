def hello(event, context):
    print("Hello Ankur")


    